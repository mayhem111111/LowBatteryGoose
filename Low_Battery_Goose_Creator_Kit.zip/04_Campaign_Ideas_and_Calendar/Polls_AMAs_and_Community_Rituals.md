# Polls, AMA and recurring ritual kit

## 12 ready poll prompts
1. What drained you most today? Work / Lack of sleep / Crypto charts / People.
2. Goose Court: is cold coffee a crime? Yes / Definitely / Call the goose lawyer.
3. Next Honk Arcade theme? Office Chaos / Caffeine Collapse / No-Sleep Olympics / Goose Court.
4. What is your goose rank? Junior Honker / Senior Honker / Chief Honk Officer / Exiled Waterfowl.
5. Which new Bingo square? 47 tabs open / Another meeting / Lost my charger / Coffee failed.
6. Which format do you like? Meme images / 10-second clips / Polls / Game nights.
7. When should we do community Q&As? Morning PT / Afternoon PT / Evening PT.
8. Best meme title? HONKPOCALYPSE / FLIGHT DELAYED / BATTERY FUNERAL / HONK AGAIN.
9. Should the goose have a nemesis? Alarm Clock / Monday / Low Wi-Fi / All of them.
10. Favorite low-energy survival skill? Nap / Walk / Snack / Staring into space.
11. Which badge should we add? Chaos Goose / Certified Honker / Nap General / Coffee Survivor.
12. What should a weekly update cover first? Games / Transparency / Events / Launch status.

## AMA outline (20 minutes)
- 0–2 min: Welcome, founder and community introductions.
- 2–5 min: Project narrative and what is demonstrably built.
- 5–10 min: Games, free participation, volunteers.
- 10–17 min: Community questions, including market risks and official-source verification.
- 17–20 min: Recap next verifiable milestones and where updates will appear.

## Tough questions and honest response framing
- 'When exactly is launch?' → 'Not confirmed yet; official announcement only when verified.'
- 'What if the token dumps?' → 'Crypto assets can lose value. No promise of profits or price support.'
- 'Will dev sell?' → 'Founder wallet holdings and intended sales need to be disclosed and checked; no blanket promises.'
- 'Can I buy early?' → 'Do not use unofficial links or pay strangers. Wait for official verified mint address.'
- 'Do moderators get paid?' → 'Volunteer roles do not imply payment or token rewards; any future arrangement requires a separate clear agreement.'
- 'Will there be airdrops?' → 'None is established in this kit; no implied reward.'

## Community rituals
Mon: Goose HR complaint desk. Tue: Goose Court poll. Wed: 1% Honk Bingo results. Thu: Original meme remix. Fri: Flock Spotlight. Weekend: Tiny victory / weekly build update. Make participation optional and kind.
