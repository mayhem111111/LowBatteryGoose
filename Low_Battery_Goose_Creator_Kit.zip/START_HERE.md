# LOW BATTERY GOOSE — CREATIVE PARTNER KIT 🪿🔋
**For: Community Content & Narrative Lead / volunteer contributors**  
**Compiled: November 3, 2026**  
**Status at handoff: PRE-LAUNCH; no independently verified public mint address in this kit.**

## Start in 5 minutes
1. Open `01_Artwork/` for the real goose mascot, banners, X/Telegram avatar variants and two ready-to-share promotional illustrations.
2. Read `02_Brand_and_Direction/Brand_Guide.md` and `.../Project_Narrative.md`.
3. Choose a post from `03_Ready_To_Post/` or create your own original remix.
4. For *your own* X account: post honestly, disclose if you have a promotional relationship, and link to the official community if relevant. For the *project's official accounts*: submit copy/art for founder approval before publishing.
5. Put proposed campaign ideas, polls and short videos in the shared review conversation. Use the 14-day calendar as a flexible template; do not announce a launch date just because a template mentions launch preparation.

## The core idea
**Running on 1%. Still honking.** Exhausted, funny, persistent, and extremely relatable. We are inviting people into a lighthearted Solana meme community; we are NOT promising that early buyers will profit.

## Official project links
- Website: https://lowbatterygoose.pages.dev
- X: https://x.com/LowBatteryGoose
- Community: https://t.me/LowBatteryFlock
- Telegram announcements: https://t.me/LowBatteryGooseSOL
- Honk Bingo: https://lowbatterygoose.pages.dev/honk-arcade-v6.html
- Honk Arcade bot: https://t.me/LowBatteryGooseGamesBot
- Planned launch venue: https://pump.fun

**VERIFY BEFORE POSTING:** Is the token actually minted? Has the founder approved an exact launch time? Is V7 of Honk Bingo deployed? Is the URL still live? If uncertain, say 'launch details TBA' or ask the founder.

## Folder map
- `01_Artwork`: reusable brand images and a screenshot reference
- `02_Brand_and_Direction`: story, style, tone, FAQ, creative boundaries
- `03_Ready_To_Post`: X and Telegram copy banks
- `04_Campaign_Ideas_and_Calendar`: challenges, polls, reels and a two-week schedule
- `05_Handoff_and_Security`: volunteer role, review workflow, message to send

## Permission boundary
Sharing these creative materials **does not** grant access to Telegram admin, X credentials, BotFather token, wallet, treasury, Pump.fun creator account, Cloudflare, or private documents. Never ask members for wallet information or promise profits, airdrops or guaranteed allocations.
