# Asset catalog and use cases

All files in `01_Artwork` come from the existing Low Battery Goose work in this project. Image sources have been recovered and included here; nothing in this handoff requires accessing ChatGPT to retrieve the files.

| File | Format | Recommended use |
|---|---|---|
| goose-mascot-1024.png | Square 1024x1024 | Consistent mascot, simple meme remixes |
| goose-mascot.svg | Scalable SVG | Vector layout / editable compositions |
| goose-banner-1500x500.png | Wide 1500x500 | Banners, cover / header reference |
| goose-banner.svg | Scalable SVG | Header layout edits |
| x-avatar-400.png | Square 400x400 | X profile / identity reference |
| telegram-avatar-512.png | Square 512x512 | Telegram icon / identity reference |
| x-header-1500x500.png | Wide 1500x500 | X header, visual reference |
| running-on-one-percent.png | Square generated illustration | Meme/awareness post |
| prelaunch-exhausted-goose.png | Square generated illustration | Explicit PRE-LAUNCH promo (update/remove after token launches) |
| honk-bingo-screen-reference.png | Tall screenshot | Demo/reference only; do not claim it shows current live deployment |

## Editing notes
- Keep copy legible on a phone; don't crop the battery or goose's head.
- Where the graphic says 'pre-launch' or 'TBA,' do not reuse after launch without updating the graphic.
- Use original graphics with truthful captions; avoid implying endorsement by Pump.fun, Solana, Telegram, X or OpenAI.
- Don't repackage/transfer the assets for unrelated projects without the founder's authorization.
- Credit volunteers for original submissions and ask permission before featuring their content.
