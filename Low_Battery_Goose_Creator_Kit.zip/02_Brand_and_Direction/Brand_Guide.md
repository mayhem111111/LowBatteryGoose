# Brand guide: Low Battery Goose ($LBG)

## Identity
- Name: **Low Battery Goose**
- Proposed ticker: **$LBG** (pre-launch as of this kit)
- Chain: **Solana**
- Planned launch: **Pump.fun**; date/time **TBA until founder confirms**
- Tagline: **Running on 1%. Still honking.**
- Alternate line: **The battery is dying. The goose is not.**
- Mascot: minimal, slightly sleepy white/cream goose with an orange beak and 1% battery.
- Brand idea: **Exhausted people, undefeated goose energy.** Internet humor about barely functioning but showing up anyway.

## Visual direction
- Lime **#CDF45C** (primary); dark ink **#19251E**; cream **#FFFCEB**; orange beak as accent.
- Rounded flat shapes, thick outlines, minimal clutter, high-contrast type, one major joke per image.
- Social formats: 1:1 square and 4:5 vertical for feeds; 16:9 for X headers; mobile-first text. Leave room for platform cropping.
- Keep the goose visibly recognizable. Exaggerated fainting / sleepy expressions OK. Avoid graphic harm or 'dying' imagery.
- Use provided master art, not random lookalike geese. Avoid pretending unrelated third-party art is official.

## Voice
- Informal, goofy, warm, self-aware; short sentences and punchlines.
- 'The coffee resigned.' 'Our emotional support goose needs an emotional support goose.'
- Make it feel like a person, not a template: vary opening lines; don't paste the same joke under 100 posts.
- Be humble when talking about trading: the token is speculative, no profit assurances.

## Five content pillars
1. **Relatable exhaustion:** coffee, work, sleep, bills, tabs open, social fatigue.
2. **Running joke/character:** goose drama, fictitious goose court, honk emergency broadcasts.
3. **Participation:** Honk Bingo, meme remixes, Battery Check, polls.
4. **Build-in-public:** actual shipped features, bugs fixed, founder updates and realistic next steps.
5. **Spotlight:** credit original memes, questions, volunteer contributions (with permission).

## Helpful hashtags
Use sparingly: #LowBatteryGoose #RunningOn1Percent #HonkBingo and only relevant Solana references. Don't overload each post.

## Good vs bad
GOOD: 'Show me your last brain cell in meme form. Funniest original joke gets a shoutout.'
BAD: 'Buy now! Guaranteed 10x!' or 'Developers can't sell!' unless such facts are verifiably established (and even then no price guarantee).
GOOD: 'Pump.fun launch details will be shared when confirmed.'
BAD: 'Launching at 6 PM tomorrow' without explicit founder confirmation.
