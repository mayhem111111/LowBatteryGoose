# Community Content & Narrative Lead — starter charter

**Role:** Volunteer Community Content & Narrative Lead (initial trial: 7 days, extend by mutual agreement).  
**Compensation:** None promised. No automatic token allocation, paid role or equity claim. Any later arrangement needs a separate written agreement.

## Their creative freedom
- Draft original jokes, memes, posts, X threads, polls, quizzes, educational materials, short video concepts and Q&A outlines.
- Suggest creative directions and make independent, truthful posts on their **own** account (with clear project relationship disclosure where applicable).
- Build community conversations, gather feedback, flag scams and misleading claims.
- Help with a weekly report: work submitted, content that resonated, unanswered questions.

## Founder approval required before
- Publishing from the *official* Low Battery Goose accounts.
- Announcing dates, mint address, presales, tokenomics, fee arrangements, wallets, LP claims, partnerships, paid contests, rewards or investor claims.
- Launching AMAs as an official event, announcing a speaker/guest, or inviting official collaborators.
- Any expense, deal or hiring promise, or use of community member photos/posts without permission.

## Not permitted
- No ownership/admin privileges by default; no credentials, passwords, API tokens, private keys, wallet addresses that are not public, or treasury access.
- No simulated volume, fake replies, mass unsolicited DMs, 'buy now' coordinated shilling, trade promises, fake airdrops or wallet connection bait.
- No copy/paste blasts under unrelated influencer posts.
- No misleading claims of affiliation with Pump.fun, Solana, Telegram, X or OpenAI.

## First-week output
Day 1: Read kit and propose 3 content themes. Day 2: Draft 3 X posts and 1 Telegram poll. Day 3: Make 1 original meme. Day 4: Suggest 1 short video with script. Day 5: Summarize genuine member questions. Day 6: Package 1 mini campaign. Day 7: Review together, discuss next role and permissions.

## Review pipeline (simple)
1. Contributor submits: proposed text + attached visual + target platform + intended time.
2. Founder/authorized editor reviews facts, authenticity, ethics, spelling and image rights.
3. Approved content is queued in the official scheduler or posted by founder.
4. Track meaningful conversations, actual game participation, and original meme shares rather than only likes.
5. Correct mistakes publicly and promptly.

## Attribution
Credit original creator handles when they want public credit; otherwise obtain consent before naming. Do not share user DMs without permission. Explicit permission is needed for reusing member art.
