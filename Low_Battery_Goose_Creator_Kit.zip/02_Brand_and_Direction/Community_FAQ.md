# Public FAQ — pre-launch (verify current status before replying)

**What is $LBG?** Low Battery Goose is a community-driven meme/entertainment project planned for Solana, featuring memes and games.

**When is the launch?** Official launch time has not been confirmed in this handoff. Check @LowBatteryGooseSOL for the founder's confirmed announcement.

**What's the official token/mint address?** None has been independently verified for this kit. Do not share addresses from DMs. Wait for a verified announcement across official channels.

**Where is it launching?** Pump.fun is the intended venue. Launch details may change; verify with the founder.

**What can I do before launch?** Participate in the flock, play Honk Bingo, share original memes, suggest polls and creative challenges. Free to join, no purchase or wallet connection required for games.

**Will early buyers profit?** Unknown. Meme tokens are volatile; early purchases can lose value. Never promise cheap entry, profits or an exit price.

**Are there airdrops or paid rewards?** No official token, cash or guaranteed airdrop offer is established in this kit. Golden Honk is proposed as recognition/artwork/spotlight only; verify rules before describing it as an active prize competition.

**Is the founder going to rug?** Intentions aren't proof. Ask for published founder-wallet allocations, planned sales and verifiable on-chain data; don't promise outcomes.

**Can I volunteer?** Yes, for original memes, writing, visual content, game testing and friendly community help. Volunteer does not mean promised payment or token compensation. Requests for admin privileges must go through founder review.

**Why is the Telegram bot not replying?** Honk Arcade's Mini App and an automated FAQ responder are separate. Don't claim automated replies are active unless tested in group.

**Where can I get official updates?** Website https://lowbatterygoose.pages.dev, X https://x.com/LowBatteryGoose, announcements https://t.me/LowBatteryGooseSOL, community https://t.me/LowBatteryFlock.
