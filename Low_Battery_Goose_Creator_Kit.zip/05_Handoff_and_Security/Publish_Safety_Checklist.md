# Before publishing anything

[ ] Does the post say 'pre-launch' unless the mint is independently verified?
[ ] Are all platform and social links the real official links?
[ ] Does it avoid promised earnings, cheap-buy claims, investment guarantees, 'no rug' certainty or FOMO pressure?
[ ] Is any launch time founder-confirmed and approved?
[ ] Are founder wallets, tokenomics, fees and partners claimed only after verification?
[ ] Is the image art included in our project or permissioned for use?
[ ] Is the submission original, relevant and not copied across dozens of unrelated posts?
[ ] Would I be comfortable if someone screenshotted this and treated it as an official statement?
[ ] Has the founder signed off if posting from official project accounts or stating project facts?
[ ] Is the post respectful and free of phishing links, wallet-connect requests or private information?

If a fact is uncertain, remove it. The official project's launch status is not a joke. Don't conceal that a contributor has a promotional relationship to the project.
